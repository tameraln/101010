<?php


abstract class Table
{
    abstract public function validate();
}